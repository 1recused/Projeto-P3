import React from 'react';
import { Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './pages/home';
import Login from './pages/login';
import Signup from './pages/signup';
import './App.css'
import Planosdetreino from './pages/planosdetreino';
import Homepage from './pages/homepage';
import EditProfile from './pages/editprofile';
import Progress from './pages/progress';
import QrCodePage from './pages/qrcode';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/homepage" element={<Homepage />} />
      <Route path="/treinos" element={<Planosdetreino />} />
      <Route path="/editprofile" element={<EditProfile />} />
      <Route path="/progress" element={<Progress />} />
      <Route path="/qrcodepage" element={<QrCodePage />} /> {/* Alterado para /qrcodepage */}
    </Routes>
  );
}

export default App;