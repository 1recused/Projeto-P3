import React from 'react';

const PRIMARY = "#a084e8";
const PRIMARY_DARK = "#7C4585";
const BG = "#f7f3ff";

const Footer = () => {
  return (
    <footer
      style={{
        background: BG,
        borderTopLeftRadius: 14,
        borderTopRightRadius: 14,
        marginTop: 24,
        boxShadow: "0 -1px 8px rgba(160,132,232,0.10)",
        fontFamily: "'Inter', 'Roboto', Arial, sans-serif",
        fontSize: 14,
        height: "4cm",
        minHeight: "4cm",
        maxHeight: "4cm",
        overflow: "hidden",
        width: "100%"
      }}
    >
      <div className="container h-100 d-flex flex-column justify-content-between py-2">
        <div className="row align-items-center h-100">
          <div className="col-lg-6 col-md-12 mb-1 d-flex flex-column justify-content-center">
            <h5 style={{ color: PRIMARY_DARK, fontWeight: 700, letterSpacing: 1, fontSize: 16, marginBottom: 6 }}>
              Fitness Evolution 2025
            </h5>
            <p style={{ color: "#5a4b7c", fontSize: 13, marginBottom: 0 }}>
              O seu espaço para evolução física e bem-estar.
            </p>
          </div>
          <div className="col-lg-3 col-md-6 mb-1 d-flex flex-column justify-content-center">
            <h5 style={{ color: PRIMARY_DARK, fontWeight: 600, fontSize: 13, marginBottom: 6 }}>Links</h5>
            <ul className="list-unstyled mb-0" style={{ fontSize: 12 }}>
              <li className="mb-1">
                <a href="#faq" style={{ color: PRIMARY, textDecoration: "none" }}>FAQ</a>
              </li>
              <li className="mb-1">
                <a href="#classes" style={{ color: PRIMARY, textDecoration: "none" }}>Aulas</a>
              </li>
              <li className="mb-1">
                <a href="#pricing" style={{ color: PRIMARY, textDecoration: "none" }}>Preços</a>
              </li>
              <li>
                <a href="#safety" style={{ color: PRIMARY, textDecoration: "none" }}>Segurança</a>
              </li>
            </ul>
          </div>
          <div className="col-lg-3 col-md-6 mb-1 d-flex flex-column justify-content-center">
            <h5 style={{ color: PRIMARY_DARK, fontWeight: 600, fontSize: 13, marginBottom: 6 }}>Horário</h5>
            <table className="table" style={{ borderColor: "#e0d7fa", background: "transparent", fontSize: 12, marginBottom: 0 }}>
              <tbody>
                <tr>
                  <td style={{ color: "#5a4b7c" }}>Seg - Sex:</td>
                  <td style={{ color: "#5a4b7c" }}>8h - 21h</td>
                </tr>
                <tr>
                  <td style={{ color: "#5a4b7c" }}>Sáb - Dom:</td>
                  <td style={{ color: "#5a4b7c" }}>8h - 13h</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div
          className="text-center"
          style={{
            background: "#ede7fa",
            color: PRIMARY_DARK,
            fontSize: 11,
            borderBottomLeftRadius: 14,
            borderBottomRightRadius: 14,
            marginTop: 4,
            padding: "3px 0"
          }}
        >
          © {new Date().getFullYear()} Fitness Evolution. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
};

export default Footer;