import React from 'react';
import { Navbar, Container, Button, Image } from 'react-bootstrap';

const Header = () => {
    return (
        <Navbar bg="light" expand="lg">
            <Container>
                <Navbar.Brand href="#home">Site Title</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse className="justify-content-end">
                    <Button variant="outline-primary">
                        <Image
                            src="https://via.placeholder.com/30"
                            roundedCircle
                            alt="Avatar"
                            style={{ width: '30px', height: '30px' }}
                        />
                    </Button>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
};

export default Header;