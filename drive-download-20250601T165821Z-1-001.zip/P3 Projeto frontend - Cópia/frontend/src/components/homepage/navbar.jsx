import React, { useState } from 'react';
import {
  MDBContainer,
  MDBNavbar,
  MDBNavbarBrand,
  MDBNavbarToggler,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBIcon,
  MDBCollapse
} from 'mdb-react-ui-kit';

const AppNavbar = () => {
  const [openNav, setOpenNav] = useState(false);

  return (
    <MDBNavbar expand='lg' light style={{
      background: 'linear-gradient(90deg, #a084e8 0%, #7C4585 100%)',
      boxShadow: '0 2px 12px rgba(160,132,232,0.13)'
    }}>
      <MDBContainer fluid>
        <MDBNavbarBrand href='/' style={{
          color: '#fff',
          fontWeight: 900,
          fontSize: 28,
          letterSpacing: 2,
          textShadow: '0 2px 12px #7C4585, 0 1px 0 #a084e8'
        }}>
          <MDBIcon icon='dumbbell' fas style={{ marginRight: 10 }} />
          Fitness Evolution
        </MDBNavbarBrand>

        <MDBNavbarToggler
          aria-expanded='false'
          aria-label='Toggle navigation'
          onClick={() => setOpenNav(!openNav)}
          style={{ borderColor: '#fff' }}
        >
          <MDBIcon icon='bars' fas style={{ color: '#fff' }} />
        </MDBNavbarToggler>

        <MDBCollapse navbar open={openNav}>
          <MDBNavbarNav className="ms-auto mb-2 mb-lg-0">
            <MDBNavbarItem>
              <MDBNavbarLink active aria-current='page' href='/' style={{ color: '#fff', fontWeight: 600 }}>
                Home
              </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>
              <MDBNavbarLink href='/treinos' style={{ color: '#fff', fontWeight: 600 }}>
                Planos de Treino
              </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>
              <MDBNavbarLink href='/progress' style={{ color: '#fff', fontWeight: 600 }}>
                Progresso
              </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>
              <MDBNavbarLink href='/personal' style={{ color: '#fff', fontWeight: 600 }}>
                Personal Trainer
              </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>
              <MDBNavbarLink href='/aulas' style={{ color: '#fff', fontWeight: 600 }}>
                Aulas de Grupo
              </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>
              <MDBNavbarLink href='/nutricao' style={{ color: '#fff', fontWeight: 600 }}>
                Nutrição
              </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>
              <MDBNavbarLink href='/editprofile' style={{ color: '#fff', fontWeight: 600 }}>
                Perfil
              </MDBNavbarLink>
            </MDBNavbarItem>
          </MDBNavbarNav>
        </MDBCollapse>
      </MDBContainer>
    </MDBNavbar>
  );
};

export default AppNavbar;