import React from 'react';
import { Card, Button } from 'react-bootstrap';
import { FaEdit, FaTrash } from 'react-icons/fa';

const CardTreinos = ({ titulo, descricao, descricaoExercicio, onEdit, onDelete }) => {
    return (
        <Card style={{ width: '18rem', margin: '1rem' }}>
            <Card.Body>
                <Card.Title>{titulo}</Card.Title>
                <Card.Text>{descricao}</Card.Text>
                <Card.Subtitle className="mb-2 text-muted">"Exercício"</Card.Subtitle>
                <Card.Text>{descricaoExercicio}</Card.Text>
                <div className="d-flex justify-content-between">
                    <Button variant="primary" onClick={onEdit}>
                        <FaEdit /> Editar
                    </Button>
                    <Button variant="outline-danger" onClick={onDelete}>
                        <FaTrash /> Apagar
                    </Button>
                </div>
            </Card.Body>
        </Card>
    );
};

export default CardTreinos;