import React, { useState } from "react";
import { Container, Row, Col, Card, Form, Button, Image } from "react-bootstrap";

// Cores base do login.jsx
const PRIMARY = "#a084e8";
const PRIMARY_DARK = "#7C4585";
const BG_IMG = "https://images.unsplash.com/photo-1546483875-ad9014c88eba?q=80&w=1982&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";

const EditProfile = () => {
  const [profile, setProfile] = useState({
    name: "",
    birthday: "",
    gender: "",
    photo: null,
    photoURL: "https://via.placeholder.com/150",
    email: "",
    password: "",
    phone: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfile({
        ...profile,
        photo: file,
        photoURL: URL.createObjectURL(file),
      });
    }
  };

  const handleUpdate = (e) => {
    e.preventDefault();
    alert("Perfil atualizado!");
  };

  const handleDelete = () => {
    alert("Conta excluída!");
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        width: "100vw",
        overflow: "hidden",
        position: "relative",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* Background desfocado (blur 6px ~ 65%) */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 0,
          background: `url('${BG_IMG}') center/cover no-repeat`,
          filter: "blur(6px) brightness(0.65)",
          width: "100vw",
          height: "100vh",
        }}
      />
      {/* Overlay para escurecer um pouco */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 1,
          background: "rgba(40,30,60,0.18)",
        }}
      />
      <Container style={{ position: "relative", zIndex: 2 }}>
        <Row className="justify-content-center">
          <Col xs={12} md={8} lg={5}>
            <Card
              style={{
                borderRadius: "2rem",
                boxShadow: "0 8px 32px 0 rgba(80,0,120,0.10)",
                background: "rgba(255,255,255,0.97)",
                border: "none",
                padding: "2.5rem 0.5rem 1.5rem 0.5rem",
                position: "relative",
                overflow: "visible",
              }}
            >
              {/* Título visível acima do avatar */}
              <h2
                className="text-center mb-4"
                style={{
                  fontWeight: 700,
                  color: "#4B267D",
                  letterSpacing: 1,
                  marginBottom: 32,
                  marginTop: 0,
                  zIndex: 2,
                  position: "relative",
                }}
              >
                Editar Perfil
              </h2>
              {/* Avatar circular com botão de editar, mais para baixo */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: 0 }}>
                <div style={{
                  position: "relative",
                  width: 120,
                  height: 120,
                  marginBottom: 12,
                }}>
                  <Image
                    src={profile.photoURL}
                    roundedCircle
                    width={120}
                    height={120}
                    alt="Foto de perfil"
                    style={{
                      objectFit: "cover",
                      border: `4px solid ${PRIMARY}`,
                      background: "#f8f9fa",
                      boxShadow: "0 2px 12px 0 rgba(160,132,232,0.10)",
                    }}
                  />
                  {/* Botão de editar foto centralizado na base do círculo */}
                  <label htmlFor="photo-upload" style={{
                    position: "absolute",
                    left: "50%",
                    bottom: -18,
                    transform: "translateX(-50%)",
                    background: PRIMARY,
                    borderRadius: "50%",
                    width: 38,
                    height: 38,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    border: "3px solid #fff",
                    boxShadow: "0 2px 8px 0 rgba(160,132,232,0.15)",
                  }}>
                    <svg width="20" height="20" fill="#fff" viewBox="0 0 24 24">
                      <path d="M12.9 4.22l1.42-1.42a2 2 0 012.83 0l2.05 2.05a2 2 0 010 2.83l-1.42 1.42M5 13.94l7.07-7.07 4.95 4.95-7.07 7.07H5v-4.95z"/>
                    </svg>
                    <input
                      id="photo-upload"
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoChange}
                      style={{ display: "none" }}
                    />
                  </label>
                </div>
                <div style={{ fontSize: 13, color: "#888", marginTop: 32, marginBottom: 8 }}>
                  Faça upload da sua foto
                </div>
                <h3 style={{
                  fontWeight: 700,
                  color: "#4B267D",
                  marginBottom: 0,
                  marginTop: 8,
                  fontSize: 24,
                  letterSpacing: 0.5,
                }}>
                  {profile.name || "Seu Nome"}
                </h3>
                <span style={{
                  color: "#a084e8",
                  fontWeight: 500,
                  fontSize: 15,
                  marginBottom: 10,
                }}>
                  {profile.email || "seu@email.com"}
                </span>
              </div>
              <Form onSubmit={handleUpdate} style={{ marginTop: 16 }}>
                <Form.Group className="mb-3">
                  <Form.Label style={{ fontWeight: 600, color: "#4B267D" }}>Nome</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={profile.name}
                    onChange={handleChange}
                    placeholder="Seu nome"
                    autoComplete="off"
                    required
                    style={{ borderRadius: 10, border: "1px solid #e0e0e0", background: "#faf7ff" }}
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label style={{ fontWeight: 600, color: "#4B267D" }}>Data de nascimento</Form.Label>
                  <Form.Control
                    type="date"
                    name="birthday"
                    value={profile.birthday}
                    onChange={handleChange}
                    required
                    style={{ borderRadius: 10, border: "1px solid #e0e0e0", background: "#faf7ff" }}
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label style={{ fontWeight: 600, color: "#4B267D" }}>Gênero</Form.Label>
                  <Form.Select
                    name="gender"
                    value={profile.gender}
                    onChange={handleChange}
                    required
                    style={{ borderRadius: 10, border: "1px solid #e0e0e0", background: "#faf7ff" }}
                  >
                    <option value="">Selecione</option>
                    <option value="male">Masculino</option>
                    <option value="female">Feminino</option>
                    <option value="other">Outro</option>
                  </Form.Select>
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label style={{ fontWeight: 600, color: "#4B267D" }}>Email</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    value={profile.email}
                    onChange={handleChange}
                    placeholder="Seu email"
                    autoComplete="off"
                    required
                    style={{ borderRadius: 10, border: "1px solid #e0e0e0", background: "#faf7ff" }}
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label style={{ fontWeight: 600, color: "#4B267D" }}>Senha</Form.Label>
                  <Form.Control
                    type="password"
                    name="password"
                    value={profile.password}
                    onChange={handleChange}
                    placeholder="Nova senha"
                    autoComplete="new-password"
                    required
                    style={{ borderRadius: 10, border: "1px solid #e0e0e0", background: "#faf7ff" }}
                  />
                </Form.Group>
                <Form.Group className="mb-4">
                  <Form.Label style={{ fontWeight: 600, color: "#4B267D" }}>Telefone</Form.Label>
                  <Form.Control
                    type="tel"
                    name="phone"
                    value={profile.phone}
                    onChange={handleChange}
                    placeholder="Seu telefone"
                    autoComplete="off"
                    style={{ borderRadius: 10, border: "1px solid #e0e0e0", background: "#faf7ff" }}
                  />
                </Form.Group>
                <div className="d-grid gap-2">
                  <Button
                    type="submit"
                    size="lg"
                    style={{
                      background: PRIMARY,
                      border: "none",
                      borderRadius: 10,
                      fontWeight: 700,
                      fontSize: 17,
                      boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                      transition: "box-shadow 0.2s, background 0.2s",
                    }}
                    onMouseOver={e => e.currentTarget.style.background = PRIMARY_DARK}
                    onMouseOut={e => e.currentTarget.style.background = PRIMARY}
                  >
                    Atualizar Perfil
                  </Button>
                  <Button
                    variant="outline-danger"
                    size="lg"
                    onClick={handleDelete}
                    style={{
                      borderRadius: 10,
                      fontWeight: 600,
                      fontSize: 17,
                      borderWidth: 2,
                      marginTop: 6,
                    }}
                  >
                    Excluir Conta
                  </Button>
                </div>
              </Form>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default EditProfile;