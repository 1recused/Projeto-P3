import React from "react";
import { Container,Button, Box, Typography, Stack } from "@mui/material";
import AppNavbar from '../components/homepage/navbar';
import {makeStyles} from "@mui/styles";
import { FaSignInAlt, FaUserPlus }  from "react-icons/fa";

const useStyles = makeStyles((theme) => ({
 root:{
  display: "flex",
  flexDirection: "column",
  color: "#fff",
  minHeight: "100vh",
  backgroundColor: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
 },
backgroundImage: {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundImage: 'url(https://images.unsplash.com/photo-1571902943202-507ec2618e8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80)',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    position: 'relative',
    '&::before': {
      content: '""',
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.6)',
    }
  },
  overlay: {
    position: "relative",
    zIndex: 1,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    padding:4,
    borderRadius: 5,
    boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.15)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    backdropFilter: "blur(10px)",
    maxwidth: "600px",
  },
  title: {
  
  
    fontWeight: "bold",
    marginBottom:2,
    textshadow: "2px 2px 4px rgba(0, 0, 0, 0.5)",
  },
  description: {
    marginBottom:4,
    opacaty: 0.8,

  },
  loginBtn: {
    backgroundColor: "#9aa6B2",
    borderColor: "#9aa6B2",
    color: "#fff",
    '&:hover': {
      backgroundColor: "#7C4585",
      transform:'translateY(-2px)',
      borderColor: "#0056b3",
    },
  },
  signupBtn: {
    backgroundColor: "#9aa6B2",
    borderColor: "#9aa6B2",
    color: "#fff",
    '&:hover': {
      backgroundColor: "#7C4585",
      transform:'translateY(-2px)',
      borderColor: "#218838",
    },
  }
}));
const Home = () => {
  const classes = useStyles();
  
  return (
    <>
    {/* <AppNavbar />  */}
    <div className={classes.root}>
    
      <div className={classes.backgroundImage}>
        <Container className={classes.overlay}>
          <Stack spacing={2} alignItems="center" justifyContent="center">
            <Typography variant="h2" className={classes.title}>
              Fitness Evolution
            </Typography>
            <Typography variant="h5" className={classes.description}>
              A tua Jornada Começa Aqui. 
            </Typography>
            <Stack direction="row" spacing={2}>
              <Button variant="contained" className={classes.loginBtn} startIcon={<FaSignInAlt />} href="/login">
                Login
              </Button>
              <Button variant="contained" className={classes.signupBtn} startIcon={<FaUserPlus />} href="/signup">
                Criar Conta
              </Button>
            </Stack>
          </Stack>
        </Container>
      </div>
    </div>
    </>
  );
};
export default Home;