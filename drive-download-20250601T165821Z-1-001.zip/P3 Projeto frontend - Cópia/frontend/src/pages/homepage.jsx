import React from "react";
import Footer from "../components/footer";
import AppNavbar from "../components/homepage/navbar";
import { Container, Row, Col, Card, Button, Image } from "react-bootstrap";

const bgUrl = "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?q=80&w=1975&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";
const PRIMARY = "#a084e8";
const PRIMARY_DARK = "#7C4585";
const AVATAR_URL = "https://randomuser.me/api/portraits/men/32.jpg"; // Exemplo de avatar

const Homepage = () => {
  return (
    <>
      <div
        style={{
          minHeight: "100vh",
          width: "100vw",
          overflow: "hidden",
          fontFamily: "'Inter', 'Roboto', Arial, sans-serif",
          position: "relative",
        }}
      >
        {/* Navbar */}
        <AppNavbar />

        {/* Blurred Background */}
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 0,
            background: `url('${bgUrl}') center/cover no-repeat`,
            filter: "blur(8px)",
            transform: "scale(1.05)",
          }}
        />
        {/* Overlay for slight darkening */}
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1,
            background: "rgba(40,30,60,0.18)",
          }}
        />
        {/* Main Content */}
        <div
          style={{
            position: "relative",
            zIndex: 2,
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "flex-start",
            width: "100vw",
            padding: "2vw 0 0 0",
          }}
        >
          {/* Header com título e avatar */}
          <Container style={{ maxWidth: 950, marginBottom: 18 }}>
            <Row className="align-items-center">
              <Col>
                <span
                  style={{
                    fontWeight: 900,
                    fontSize: 44,
                    color: "#4B267D",
                    letterSpacing: 2,
                    fontFamily: "'Inter', 'Roboto', Arial, sans-serif",
                    textShadow: "0 4px 24px rgba(160,132,232,0.10)",
                    lineHeight: 1.1,
                  }}
                >
                  Fitness Evolution
                </span>
              </Col>
              <Col xs="auto">
                <Image
                  src={AVATAR_URL}
                  roundedCircle
                  width={70}
                  height={70}
                  alt="Avatar"
                  style={{
                    border: `3px solid ${PRIMARY}`,
                    boxShadow: "0 2px 8px rgba(160,132,232,0.15)",
                    objectFit: "cover",
                    background: "#fff",
                  }}
                />
              </Col>
            </Row>
          </Container>

          {/* Bem-vindo estilizado */}
          <div
            style={{
              background: "linear-gradient(90deg, #a084e8 0%, #ede7fa 100%)",
              borderRadius: 14,
              boxShadow: "0 4px 18px rgba(160,132,232,0.13)",
              padding: "14px 0",
              marginBottom: 32,
              width: "950px",
              maxWidth: "95vw",
              textAlign: "center",
              position: "relative",
              zIndex: 2,
              border: `2px solid ${PRIMARY}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <span
              style={{
                fontWeight: 900,
                fontSize: 28,
                color: "#fff",
                letterSpacing: 2,
                textShadow: "0 2px 12px #7C4585, 0 1px 0 #a084e8",
              }}
            >
              Bem-vindo(a)
            </span>
          </div>

          {/* Cards principais - apenas 6 cards, sem duplicados */}
          <Container style={{ maxWidth: 950, marginBottom: 32 }}>
            <Row className="mb-4" style={{ gap: 0 }}>
              {/* Card 1 - Planos de treino */}
              <Col md={4} className="d-flex">
                <Card
                  style={{
                    width: "100%",
                    borderRadius: 18,
                    background: "rgba(255,255,255,0.97)",
                    boxShadow: "0 8px 32px rgba(160,132,232,0.10)",
                    border: "none",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                  }}
                  className="mb-3"
                >
                  <Card.Img
                    variant="top"
                    src="https://promofitness.com/wp-content/uploads/2020/06/artigo19.jpg"
                    style={{
                      borderTopLeftRadius: 18,
                      borderTopRightRadius: 18,
                      height: 140,
                      objectFit: "cover",
                    }}
                  />
                  <Card.Body className="d-flex flex-column">
                    <Card.Title style={{ fontWeight: 700, color: "#4B267D" }}>Planos de treino</Card.Title>
                    <Card.Text style={{ color: "#555", fontSize: 15 }}>
                      Acesse aos seus planos personalizados
                    </Card.Text>
                    <Button
                      style={{
                        background: PRIMARY,
                        border: "none",
                        borderRadius: 8,
                        fontWeight: 700,
                        fontSize: 15,
                        marginTop: "auto",
                        boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                        transition: "box-shadow 0.2s, background 0.2s"
                      }}
                      onMouseOver={e => e.currentTarget.style.background = PRIMARY_DARK}
                      onMouseOut={e => e.currentTarget.style.background = PRIMARY}
                      onClick={() => window.location.href = "/treinos"}
                    >
                      Ver planos
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
              {/* Card 2 - Meu Progresso */}
              <Col md={4} className="d-flex">
                <Card
                  style={{
                    width: "100%",
                    borderRadius: 18,
                    background: "rgba(255,255,255,0.97)",
                    boxShadow: "0 8px 32px rgba(160,132,232,0.10)",
                    border: "none",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                  }}
                  className="mb-3"
                >
                  <Card.Img
                    variant="top"
                    src="https://www.deco.proteste.pt/-/media/edideco/images/home/saude/exerc%C3%ADcio%20f%C3%ADsico/ginasio.jpg?rev=51e61510-2fba-453b-aa9a-3cc989126bfd&mw=660&hash=6F572C5023C735714EDB8EF7E15FA193"
                    style={{
                      borderTopLeftRadius: 18,
                      borderTopRightRadius: 18,
                      height: 140,
                      objectFit: "cover",
                    }}
                  />
                  <Card.Body className="d-flex flex-column">
                    <Card.Title style={{ fontWeight: 700, color: "#4B267D" }}>Meu Progresso</Card.Title>
                    <Card.Text style={{ color: "#555", fontSize: 15 }}>
                      Acompanhe a sua evolução
                    </Card.Text>
                    <Button
                      style={{
                        background: PRIMARY,
                        border: "none",
                        borderRadius: 8,
                        fontWeight: 700,
                        fontSize: 15,
                        marginTop: "auto",
                        boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                        transition: "box-shadow 0.2s, background 0.2s"
                      }}
                      onMouseOver={e => e.currentTarget.style.background = PRIMARY_DARK}
                      onMouseOut={e => e.currentTarget.style.background = PRIMARY}
                      onClick={() => window.location.href = "/progress"}
                    >
                      Ver progresso
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
              {/* Card 3 - Meu Perfil */}
              <Col md={4} className="d-flex">
                <Card
                  style={{
                    width: "100%",
                    borderRadius: 18,
                    background: "rgba(255,255,255,0.97)",
                    boxShadow: "0 8px 32px rgba(160,132,232,0.10)",
                    border: "none",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                  }}
                  className="mb-3"
                >
                  <Card.Img
                    variant="top"
                    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqcvxevxQNi3i6W_91fS3BsZ_0Yo58dnXnjamEOyFUc6LVoWYVuumgtOYmqVUjVF3sINw&usqp=CAU"
                    style={{
                      borderTopLeftRadius: 18,
                      borderTopRightRadius: 18,
                      height: 140,
                      objectFit: "cover",
                    }}
                  />
                  <Card.Body className="d-flex flex-column">
                    <Card.Title style={{ fontWeight: 700, color: "#4B267D" }}>Meu Perfil</Card.Title>
                    <Card.Text style={{ color: "#555", fontSize: 15 }}>
                      Gerencie suas informações pessoais
                    </Card.Text>
                    <Button
                      style={{
                        background: PRIMARY,
                        border: "none",
                        borderRadius: 8,
                        fontWeight: 700,
                        fontSize: 15,
                        marginTop: "auto",
                        boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                        transition: "box-shadow 0.2s, background 0.2s"
                      }}
                      onMouseOver={e => e.currentTarget.style.background = PRIMARY_DARK}
                      onMouseOut={e => e.currentTarget.style.background = PRIMARY}
                      onClick={() => window.location.href = "/editprofile"}
                    >
                      Editar perfil
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
              {/* Card 4 - Personal Trainer */}
              <Col md={4} className="d-flex">
                <Card
                  style={{
                    width: "100%",
                    borderRadius: 18,
                    background: "rgba(255,255,255,0.97)",
                    boxShadow: "0 8px 32px rgba(160,132,232,0.10)",
                    border: "none",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                  }}
                  className="mb-3"
                >
                  <Card.Img
                    variant="top"
                    src="https://media.unimedcampinas.com.br/bb0c65d5-59cc-4677-9000-d1f8ca743f78"
                    style={{
                      borderTopLeftRadius: 18,
                      borderTopRightRadius: 18,
                      height: 140,
                      objectFit: "cover",
                    }}
                  />
                  <Card.Body className="d-flex flex-column">
                    <Card.Title style={{ fontWeight: 700, color: "#4B267D" }}>Personal Trainer</Card.Title>
                    <Card.Text style={{ color: "#555", fontSize: 15 }}>
                      Treine com acompanhamento individualizado e maximize seus resultados.
                    </Card.Text>
                    <Button
                      style={{
                        background: PRIMARY,
                        border: "none",
                        borderRadius: 8,
                        fontWeight: 700,
                        fontSize: 15,
                        marginTop: "auto",
                        boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                        transition: "box-shadow 0.2s, background 0.2s"
                      }}
                      onMouseOver={e => e.currentTarget.style.background = PRIMARY_DARK}
                      onMouseOut={e => e.currentTarget.style.background = PRIMARY}
                      onClick={() => window.location.href = "/personal"}
                    >
                      Saber mais
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
              {/* Card 5 - Aulas de Grupo */}
              <Col md={4} className="d-flex">
                <Card
                  style={{
                    width: "100%",
                    borderRadius: 18,
                    background: "rgba(255,255,255,0.97)",
                    boxShadow: "0 8px 32px rgba(160,132,232,0.10)",
                    border: "none",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                  }}
                  className="mb-3"
                >
                  <Card.Img
                    variant="top"
                    src="https://aquadrenalina.com/wp-content/uploads/2012/07/HIIT-Workout-670x447.jpg"
                    style={{
                      borderTopLeftRadius: 18,
                      borderTopRightRadius: 18,
                      height: 140,
                      objectFit: "cover",
                    }}
                  />
                  <Card.Body className="d-flex flex-column">
                    <Card.Title style={{ fontWeight: 700, color: "#4B267D" }}>Aulas de Grupo</Card.Title>
                    <Card.Text style={{ color: "#555", fontSize: 15 }}>
                      Participe de aulas dinâmicas e motivadoras para todos os níveis.
                    </Card.Text>
                    <Button
                      style={{
                        background: PRIMARY,
                        border: "none",
                        borderRadius: 8,
                        fontWeight: 700,
                        fontSize: 15,
                        marginTop: "auto",
                        boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                        transition: "box-shadow 0.2s, background 0.2s"
                      }}
                      onMouseOver={e => e.currentTarget.style.background = PRIMARY_DARK}
                      onMouseOut={e => e.currentTarget.style.background = PRIMARY}
                      onClick={() => window.location.href = "/aulas"}
                    >
                      Ver horários
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
              {/* Card 6 - Nutrição */}
              <Col md={4} className="d-flex">
                <Card
                  style={{
                    width: "100%",
                    borderRadius: 18,
                    background: "rgba(255,255,255,0.97)",
                    boxShadow: "0 8px 32px rgba(160,132,232,0.10)",
                    border: "none",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                  }}
                  className="mb-3"
                >
                  <Card.Img
                    variant="top"
                    src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80"
                    style={{
                      borderTopLeftRadius: 18,
                      borderTopRightRadius: 18,
                      height: 140,
                      objectFit: "cover",
                    }}
                  />
                  <Card.Body className="d-flex flex-column">
                    <Card.Title style={{ fontWeight: 700, color: "#4B267D" }}>Nutrição</Card.Title>
                    <Card.Text style={{ color: "#555", fontSize: 15 }}>
                      Receba orientação nutricional personalizada para potencializar seus resultados.
                    </Card.Text>
                    <Button
                      style={{
                        background: PRIMARY,
                        border: "none",
                        borderRadius: 8,
                        fontWeight: 700,
                        fontSize: 15,
                        marginTop: "auto",
                        boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                        transition: "box-shadow 0.2s, background 0.2s"
                      }}
                      onMouseOver={e => e.currentTarget.style.background = PRIMARY_DARK}
                      onMouseOut={e => e.currentTarget.style.background = PRIMARY}
                      onClick={() => window.location.href = "/nutricao"}
                    >
                      Consultar
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </Container>

          {/* Cards de estatísticas menores */}
          <Container style={{ maxWidth: 950, marginBottom: 32 }}>
            <Row>
              <Col md={3} xs={6} className="mb-3">
                <Card
                  style={{
                    borderRadius: 14,
                    border: `2px solid ${PRIMARY}`,
                    boxShadow: "0 4px 16px rgba(160,132,232,0.10)",
                    background: "rgba(255,255,255,0.98)",
                    textAlign: "center",
                  }}
                >
                  <Card.Body>
                    <Card.Title style={{ fontWeight: 700, color: PRIMARY, fontSize: 22 }}>12</Card.Title>
                    <Card.Text style={{ color: "#4B267D", fontWeight: 600, fontSize: 15 }}>Treinos realizados</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={3} xs={6} className="mb-3">
                <Card
                  style={{
                    borderRadius: 14,
                    border: `2px solid ${PRIMARY}`,
                    boxShadow: "0 4px 16px rgba(160,132,232,0.10)",
                    background: "rgba(255,255,255,0.98)",
                    textAlign: "center",
                  }}
                >
                  <Card.Body>
                    <Card.Title style={{ fontWeight: 700, color: PRIMARY, fontSize: 22 }}>3</Card.Title>
                    <Card.Text style={{ color: "#4B267D", fontWeight: 600, fontSize: 15 }}>Planos ativos</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={3} xs={6} className="mb-3">
                <Card
                  style={{
                    borderRadius: 14,
                    border: `2px solid ${PRIMARY}`,
                    boxShadow: "0 4px 16px rgba(160,132,232,0.10)",
                    background: "rgba(255,255,255,0.98)",
                    textAlign: "center",
                  }}
                >
                  <Card.Body>
                    <Card.Title style={{ fontWeight: 700, color: PRIMARY, fontSize: 22 }}>8H</Card.Title>
                    <Card.Text style={{ color: "#4B267D", fontWeight: 600, fontSize: 15 }}>Tempo total de treino</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={3} xs={6} className="mb-3">
                <Card
                  style={{
                    borderRadius: 14,
                    border: `2px solid ${PRIMARY}`,
                    boxShadow: "0 4px 16px rgba(160,132,232,0.10)",
                    background: "rgba(255,255,255,0.98)",
                    textAlign: "center",
                  }}
                >
                  <Card.Body>
                    <Card.Title style={{ fontWeight: 700, color: PRIMARY, fontSize: 22 }}>85%</Card.Title>
                    <Card.Text style={{ color: "#4B267D", fontWeight: 600, fontSize: 15 }}>Meta atingida</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </Container>
          <Footer />
        </div>
      </div>
      <style>
        {`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        `}
      </style>
    </>
  );
};

export default Homepage;