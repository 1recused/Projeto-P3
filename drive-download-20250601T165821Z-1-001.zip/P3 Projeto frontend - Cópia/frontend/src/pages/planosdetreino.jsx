import React, { useState } from "react";
import { Card, Button, Container, Modal } from "react-bootstrap";

// Exercícios por dia da semana, cada um com vídeo explicativo
const planosPorDia = {
  Seg: [
    {
      nome: "Puxada frontal",
      series: "3 séries x 12 repetições",
      img: "https://img.icons8.com/color/96/lat-pulldown.png",
      descricao: "Exercício para costas, foco no latíssimo do dorso. Use barra e puxador frontal.",
      video: "https://www.youtube.com/watch?v=CAwf7n6Luuc"
    },
    {
      nome: "Remada curvada",
      series: "3 séries x 12 repetições",
      img: "https://img.icons8.com/color/96/barbell.png",
      descricao: "Trabalha toda a musculatura das costas e bíceps. Use barra e mantenha as costas retas.",
      video: "https://www.youtube.com/watch?v=roCP6wCXPqo"
    },
    {
      nome: "Pulldown com triângulo",
      series: "3 séries x 10 repetições",
      img: "https://img.icons8.com/color/96/gym.png",
      descricao: "Foco em dorsais, utilize o triângulo no puxador.",
      video: "https://www.youtube.com/watch?v=6e5QnQeF6x8"
    }
  ],
  Ter: [
    {
      nome: "Remada unilateral",
      series: "3 séries x 12 repetições",
      img: "https://img.icons8.com/color/96/dumbbell.png",
      descricao: "Foco em dorsais e bíceps. Use halter, uma mão de cada vez, apoiando o joelho no banco.",
      video: "https://www.youtube.com/watch?v=pYcpY20QaE8"
    },
    {
      nome: "Levantamento terra",
      series: "3 séries x 12 repetições",
      img: "https://img.icons8.com/color/96/deadlift.png",
      descricao: "Exercício completo para costas, glúteos e pernas. Use barra e mantenha a postura.",
      video: "https://www.youtube.com/watch?v=ytGaGIn3SjE"
    },
    {
      nome: "Rosca alternada",
      series: "3 séries x 10 repetições",
      img: "https://img.icons8.com/color/96/weightlifting.png",
      descricao: "Trabalha bíceps alternando os braços com halteres.",
      video: "https://www.youtube.com/watch?v=av7-8igSXTs"
    }
  ],
  Qua: [
    {
      nome: "Rosca direta",
      series: "3 séries x 12 repetições",
      img: "https://img.icons8.com/color/96/barbell.png",
      descricao: "Foco em bíceps. Use barra reta, cotovelos fixos ao lado do corpo.",
      video: "https://www.youtube.com/watch?v=kwG2ipFRgfo"
    },
    {
      nome: "Rosca martelo",
      series: "3 séries x 10 repetições",
      img: "https://img.icons8.com/color/96/hand-grip-strengthener.png",
      descricao: "Trabalha o antebraço e bíceps. Use halteres em pegada neutra.",
      video: "https://www.youtube.com/watch?v=zC3nLlEvin4"
    },
    {
      nome: "Rosca concentrada",
      series: "3 séries x 8 repetições",
      img: "https://img.icons8.com/color/96/arm-muscle.png",
      descricao: "Foco total no bíceps, sentado, um braço de cada vez.",
      video: "https://www.youtube.com/watch?v=0AUGkch3tzc"
    }
  ],
  Qui: [
    {
      nome: "Tríceps pulley",
      series: "3 séries x 12 repetições",
      img: "https://img.icons8.com/color/96/rope-climbing.png",
      descricao: "Foco em tríceps. Use corda ou barra no cross.",
      video: "https://www.youtube.com/watch?v=vB5OHsJ3EME"
    },
    {
      nome: "Tríceps testa",
      series: "3 séries x 10 repetições",
      img: "https://img.icons8.com/color/96/bench-press-with-dumbbells.png",
      descricao: "Deitado, leve a barra até a testa e estenda os cotovelos.",
      video: "https://www.youtube.com/watch?v=d_KZxkY_0cM"
    },
    {
      nome: "Mergulho entre bancos",
      series: "3 séries x 8 repetições",
      img: "https://img.icons8.com/color/96/parallel-bars.png",
      descricao: "Use dois bancos para apoiar as mãos e os pés, descendo o corpo.",
      video: "https://www.youtube.com/watch?v=0326dy_-CzM"
    }
  ],
  Sex: [
    {
      nome: "Desenvolvimento ombro",
      series: "3 séries x 12 repetições",
      img: "https://img.icons8.com/color/96/dumbbell.png",
      descricao: "Foco em ombros. Use halteres, suba até a altura dos ombros.",
      video: "https://www.youtube.com/watch?v=B-aVuyhvLHU"
    },
    {
      nome: "Elevação lateral",
      series: "3 séries x 10 repetições",
      img: "https://img.icons8.com/color/96/shoulder-exercise.png",
      descricao: "Trabalha o deltoide lateral. Use halteres, braços semi-flexionados.",
      video: "https://www.youtube.com/watch?v=3VcKaXpzqRo"
    },
    {
      nome: "Desenvolvimento Arnold",
      series: "3 séries x 8 repetições",
      img: "https://img.icons8.com/color/96/fitness.png",
      descricao: "Variação do desenvolvimento, girando os punhos durante o movimento.",
      video: "https://www.youtube.com/watch?v=vj2w851ZHRM"
    }
  ],
  Sáb: [
    {
      nome: "Puxada frontal",
      series: "3 séries x 12 repetições",
      img: "https://img.icons8.com/color/96/lat-pulldown.png",
      descricao: "Exercício para costas, foco no latíssimo do dorso. Use barra e puxador frontal.",
      video: "https://www.youtube.com/watch?v=CAwf7n6Luuc"
    },
    {
      nome: "Remada baixa",
      series: "3 séries x 10 repetições",
      img: "https://img.icons8.com/color/96/rowing.png",
      descricao: "Trabalha a parte média das costas. Use o aparelho de remada baixa.",
      video: "https://www.youtube.com/watch?v=ro8QFj-5t1Y"
    },
    {
      nome: "Pullover",
      series: "3 séries x 8 repetições",
      img: "https://img.icons8.com/color/96/stretching-exercises.png",
      descricao: "Exercício para dorsais e peitoral. Use halter deitado no banco.",
      video: "https://www.youtube.com/watch?v=6TSP1TRMUzs"
    }
  ],
  Dom: [
    {
      nome: "Descanso",
      series: "",
      img: "https://img.icons8.com/color/96/bed.png",
      descricao: "Dia de descanso e recuperação muscular.",
      video: "https://www.youtube.com/watch?v=1ZYbU82GVz4"
    },
    {
      nome: "Alongamento leve",
      series: "3 séries x 30 segundos",
      img: "https://img.icons8.com/color/96/yoga.png",
      descricao: "Alongue todo o corpo para relaxar e recuperar.",
      video: "https://www.youtube.com/watch?v=2L2lnxIcNmo"
    },
    {
      nome: "Caminhada",
      series: "30 minutos",
      img: "https://img.icons8.com/color/96/walking.png",
      descricao: "Caminhada leve para manter o corpo ativo mesmo no descanso."
      // Não tem vídeo!
    }
  ]
};

const grupos = ["Costas", "Bíceps", "Tríceps", "Ombro"];
const diasSemanaCompleto = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];

const PRIMARY = "#a084e8";
const PRIMARY_DARK = "#7C4585";

const cardStyle = {
  border: `1.5px solid ${PRIMARY}`,
  borderRadius: 28,
  background: "rgba(255,255,255,0.97)",
  boxShadow: "0 8px 32px 0 rgba(160,132,232,0.13)",
  padding: "2.5rem 1.5rem 2rem 1.5rem",
  maxWidth: 480,
  margin: "40px auto",
  overflow: "hidden",
  backdropFilter: "blur(2px)",
  position: "relative"
};

// Botão X fixo no topo da página
const pageCloseButtonStyle = {
  position: "fixed",
  top: 10,
  right: 18,
  fontSize: 32,
  fontWeight: 700,
  color: "#bbb",
  background: "none",
  border: "none",
  cursor: "pointer",
  zIndex: 100,
  lineHeight: 1
};

const PlanosDeTreino = () => {
  const [diaSelecionado, setDiaSelecionado] = useState("Seg");
  const [modalExercicio, setModalExercicio] = useState(null);

  const exercicios = planosPorDia[diaSelecionado] || [];

  return (
    <>
      {/* Botão X fixo no topo da página */}
      <button
        style={pageCloseButtonStyle}
        aria-label="Fechar"
        onClick={() => window.location.href = "http://localhost:5173/homepage"}
      >
        ×
      </button>
      {/* Video background with blur */}
      <div style={{
        position: "fixed",
        inset: 0,
        zIndex: 0,
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        pointerEvents: "none"
      }}>
        <video
          autoPlay
          loop
          muted
          playsInline
          style={{
            width: "100vw",
            height: "100vh",
            objectFit: "cover",
            minHeight: "100vh",
            minWidth: "100vw",
            filter: "brightness(0.7) blur(8px)",
          }}
        >
          <source src="https://cdn.pixabay.com/video/2022/12/18/143431-782373969_large.mp4" type="video/mp4" />
        </video>
      </div>
      <div
        style={{
          minHeight: "100vh",
          width: "100vw",
          overflow: "auto",
          fontFamily: "'Inter', 'Roboto', Arial, sans-serif",
          background: "transparent",
          position: "relative",
          zIndex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center"
        }}
      >
        <Container style={{ maxWidth: 540 }}>
          <Card style={cardStyle}>
            {/* Calendário superior */}
            <div style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 28,
              gap: 6
            }}>
              {diasSemanaCompleto.map((dia, idx) => (
                <div key={dia} style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  fontWeight: 600,
                  color: diaSelecionado === dia ? PRIMARY_DARK : "#888",
                  fontSize: 13,
                  minWidth: 36,
                  cursor: "pointer"
                }}
                  onClick={() => setDiaSelecionado(dia)}
                >
                  <span style={{
                    background: diaSelecionado === dia ? PRIMARY : "#ede7fa",
                    color: diaSelecionado === dia ? "#fff" : "#7C4585",
                    borderRadius: 8,
                    padding: "4px 0",
                    width: 32,
                    textAlign: "center",
                    marginBottom: 2,
                    fontWeight: diaSelecionado === dia ? 700 : 500,
                    transition: "background 0.2s, color 0.2s"
                  }}>
                    {dia}
                  </span>
                </div>
              ))}
            </div>
            {/* Grupos musculares */}
            <div style={{
              display: "flex",
              flexWrap: "wrap",
              gap: 10,
              marginBottom: 18,
              justifyContent: "center"
            }}>
              {grupos.map(grupo => (
                <span key={grupo} style={{
                  background: "#ede7fa",
                  color: PRIMARY_DARK,
                  borderRadius: 8,
                  padding: "6px 18px",
                  fontWeight: 600,
                  fontSize: 15,
                  letterSpacing: 0.2
                }}>
                  {grupo}
                </span>
              ))}
            </div>
            {/* Exercícios */}
            <div style={{
              marginTop: 18,
              marginBottom: 10,
              fontWeight: 700,
              color: PRIMARY_DARK,
              fontSize: 18,
              textAlign: "center"
            }}>
              Exercícios <span style={{ color: "#888", fontWeight: 500, fontSize: 15 }}>({exercicios.length})</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
              {exercicios.map((ex, idx) => (
                <div
                  key={ex.nome}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 18,
                    background: "#f7f5ff",
                    borderRadius: 14,
                    padding: "12px 14px",
                    border: "1.5px solid #e5dbfa",
                    boxShadow: "0 2px 12px rgba(160,132,232,0.07)",
                    cursor: "pointer"
                  }}
                  onClick={() => setModalExercicio(ex)}
                >
                  <img
                    src={ex.img}
                    alt={ex.nome}
                    style={{
                      width: 54,
                      height: 54,
                      objectFit: "contain",
                      background: "#fff",
                      borderRadius: 10,
                      border: "1px solid #e5dbfa",
                      marginRight: 6
                    }}
                    onError={e => {
                      e.target.onerror = null;
                      e.target.src = "https://img.icons8.com/color/96/dumbbell.png";
                    }}
                  />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: PRIMARY_DARK, fontSize: 16 }}>{ex.nome}</div>
                    <div style={{ color: "#555", fontWeight: 500, fontSize: 14 }}>{ex.series}</div>
                  </div>
                  {/* Só mostra o botão vídeo se houver vídeo */}
                  {!(diaSelecionado === "Dom" && ex.nome === "Caminhada") && ex.video && (
                    <Button
                      variant="outline-primary"
                      size="sm"
                      style={{
                        minWidth: 80,
                        fontWeight: 600,
                        borderRadius: 8,
                        borderColor: PRIMARY,
                        color: PRIMARY,
                        background: "#fff"
                      }}
                      onClick={e => {
                        e.stopPropagation();
                        window.open(ex.video, "_blank");
                      }}
                    >
                      Vídeo
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </Container>
      </div>
      {/* Modal de informações do exercício */}
      <Modal
        show={!!modalExercicio}
        onHide={() => setModalExercicio(null)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>{modalExercicio?.nome}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div style={{ textAlign: "center" }}>
            <img
              src={modalExercicio?.img}
              alt={modalExercicio?.nome}
              style={{
                width: 80,
                height: 80,
                objectFit: "contain",
                background: "#fff",
                borderRadius: 12,
                border: "1px solid #e5dbfa",
                marginBottom: 12
              }}
              onError={e => {
                e.target.onerror = null;
                e.target.src = "https://img.icons8.com/color/96/dumbbell.png";
              }}
            />
            <div style={{ fontWeight: 600, color: PRIMARY_DARK, fontSize: 16, marginBottom: 8 }}>
              {modalExercicio?.series}
            </div>
            <div style={{ color: "#555", fontWeight: 500, fontSize: 15 }}>
              {modalExercicio?.descricao}
            </div>
            {/* Só mostra o botão vídeo se houver vídeo e não for Caminhada no domingo */}
            {modalExercicio?.video && !(diaSelecionado === "Dom" && modalExercicio?.nome === "Caminhada") && (
              <Button
                variant="primary"
                style={{ marginTop: 18, fontWeight: 600, borderRadius: 8 }}
                onClick={() => window.open(modalExercicio.video, "_blank")}
              >
                Ver vídeo do exercício
              </Button>
            )}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setModalExercicio(null)}>
            Fechar
          </Button>
        </Modal.Footer>
      </Modal>
      <style>
        {`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        `}
      </style>
    </>
  );
};

export default PlanosDeTreino;