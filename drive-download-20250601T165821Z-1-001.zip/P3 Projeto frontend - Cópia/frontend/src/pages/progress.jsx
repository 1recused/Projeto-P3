import React, { useState } from "react";
import { Container, Row, Col, Card, Button, ProgressBar, Dropdown } from "react-bootstrap";

const bgUrl = "https://images.unsplash.com/photo-1728486145245-d4cb0c9c3470?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";
const PRIMARY = "#a084e8";
const PRIMARY_DARK = "#7C4585";

const progressData = [
  { label: "Peso", value: 72, goal: 70, unit: "kg", color: "#a084e8" },
  { label: "Gordura Corporal", value: 18, goal: 15, unit: "%", color: "#7C4585" },
  { label: "IMC", value: 23.5, goal: 22, unit: "", color: "#4B267D" },
  { label: "Músculo", value: 38, goal: 40, unit: "%", color: "#a084e8" },
];

const periods = [
  "Esta semana",
  "Este mês",
  "Últimos 3 meses",
  "Este ano"
];

// Botão X mais para cima e à direita
const closeButtonStyle = {
  position: "fixed",
  top: 10,
  right: 18,
  fontSize: 32,
  fontWeight: 700,
  color: "#bbb",
  background: "none",
  border: "none",
  cursor: "pointer",
  zIndex: 10,
  lineHeight: 1
};

const Progress = () => {
  const [selectedPeriod, setSelectedPeriod] = useState(periods[0]);

  return (
    <>
      {/* Botão X fixo no topo direito */}
      <button
        style={closeButtonStyle}
        aria-label="Fechar"
        onClick={() => window.location.href = "http://localhost:5173/homepage"}
      >
        ×
      </button>
      <div
        style={{
          minHeight: "100vh",
          width: "100vw",
          overflow: "hidden",
          fontFamily: "'Inter', 'Roboto', Arial, sans-serif",
          position: "relative",
        }}
      >
        {/* Blurred Background */}
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 0,
            background: `url('${bgUrl}') center/cover no-repeat`,
            filter: "blur(8px)",
            transform: "scale(1.05)",
          }}
        />
        {/* Overlay for slight darkening */}
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1,
            background: "rgba(40,30,60,0.18)",
          }}
        />
        {/* Main Content */}
        <div
          style={{
            position: "relative",
            zIndex: 2,
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "100vw",
            padding: "2vw",
          }}
        >
          <Card
            style={{
              width: "100%",
              maxWidth: 500,
              borderRadius: 20,
              background: "rgba(255,255,255,0.97)",
              boxShadow: "0 8px 32px rgba(80,0,120,0.10)",
              border: "none",
              padding: "2.5rem 2rem 2rem 2rem",
              position: "relative",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
              <h2 style={{ fontWeight: 700, color: "#4B267D", margin: 0, fontSize: 28, letterSpacing: 1 }}>
                Progresso
              </h2>
              <Dropdown>
                <Dropdown.Toggle
                  style={{
                    background: PRIMARY,
                    border: "none",
                    borderRadius: 8,
                    fontWeight: 600,
                    fontSize: 15,
                    padding: "6px 18px",
                  }}
                  id="dropdown-basic"
                >
                  {selectedPeriod}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  {periods.map((period) => (
                    <Dropdown.Item key={period} onClick={() => setSelectedPeriod(period)}>
                      {period}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>
            </div>
            <div>
              {progressData.map((item, idx) => {
                const percent = Math.min(100, Math.round((item.value / item.goal) * 100));
                return (
                  <div key={item.label} style={{ marginBottom: 28 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span style={{ fontWeight: 600, color: "#4B267D", fontSize: 15 }}>{item.label}</span>
                      <span style={{ fontWeight: 600, color: PRIMARY, fontSize: 15 }}>
                        {item.value}{item.unit} <span style={{ color: "#888", fontWeight: 400, fontSize: 13 }}>/ {item.goal}{item.unit}</span>
                      </span>
                    </div>
                    <ProgressBar
                      now={percent}
                      style={{
                        height: 14,
                        borderRadius: 8,
                        background: "#f0eafd",
                        marginTop: 8,
                        boxShadow: "0 2px 8px rgba(160,132,232,0.08)",
                      }}
                      variant=""
                    >
                      <div
                        style={{
                          width: `${percent}%`,
                          height: "100%",
                          background: item.color,
                          borderRadius: 8,
                          transition: "width 0.6s cubic-bezier(.4,2,.3,1)",
                        }}
                      />
                    </ProgressBar>
                  </div>
                );
              })}
            </div>
            <Button
              size="lg"
              style={{
                background: PRIMARY,
                border: "none",
                borderRadius: 10,
                fontWeight: 700,
                fontSize: 17,
                boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                transition: "box-shadow 0.2s, background 0.2s",
                marginTop: 18,
                width: "100%",
              }}
              onMouseOver={e => e.currentTarget.style.background = PRIMARY_DARK}
              onMouseOut={e => e.currentTarget.style.background = PRIMARY}
            >
              Adicionar Progresso
            </Button>
          </Card>
        </div>
      </div>
      <style>
        {`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        `}
      </style>
    </>
  );
};

export default Progress;