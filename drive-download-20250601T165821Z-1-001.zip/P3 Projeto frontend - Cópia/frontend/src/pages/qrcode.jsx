import React, { useState } from "react";
import { Button, Card, Collapse } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const monthsData = [
  {
    label: "+ MAIO 2025",
    value: "maio",
    days: [
      {
        weekday: "Quinta-Feira",
        date: "22 Maio 2025",
        entrada: "21:26",
        saida: "22:00",
        tempo: "34min",
        tipo: "acesso total",
      },
      {
        weekday: "Terça-Feira",
        date: "14 Maio 2025",
        entrada: "19:10",
        saida: "20:05",
        tempo: "55min",
        tipo: "acesso total",
      },
    ],
  },
  {
    label: "+ ABRIL 2025",
    value: "abril",
    days: [
      {
        weekday: "Sexta-Feira",
        date: "12 Abril 2025",
        entrada: "18:00",
        saida: "19:00",
        tempo: "1h00min",
        tipo: "acesso total",
      },
    ],
  },
  {
    label: "+ MARÇO 2025",
    value: "marco",
    days: [
      {
        weekday: "Quarta-Feira",
        date: "27 Março 2025",
        entrada: "20:30",
        saida: "21:10",
        tempo: "40min",
        tipo: "acesso total",
      },
    ],
  },
];

const exampleQr =
  "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=ExemploQR";

const QrCodePage = () => {
  const [showQr, setShowQr] = useState(false);
  const [openMonth, setOpenMonth] = useState(null);
  const navigate = useNavigate();

  return (
    <>
      <div
        style={{
          minHeight: "100vh",
          width: "100vw",
          overflow: "hidden",
          fontFamily: "'Inter', 'Roboto', Arial, sans-serif",
          position: "relative",
        }}
      >
        {/* Video Gym Background */}
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 0,
            overflow: "hidden",
          }}
        >
          <video
            autoPlay
            loop
            muted
            playsInline
            style={{
              width: "100vw",
              height: "100vh",
              objectFit: "cover",
              filter: "blur(8px) brightness(0.7)",
            }}
            src="https://cdn.pixabay.com/video/2025/02/26/261156_large.mp4"
          />
        </div>
        {/* Overlay for slight darkening */}
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1,
            background: "rgba(40,30,60,0.18)",
          }}
        />
        {/* Main Content */}
        <div
          style={{
            position: "relative",
            zIndex: 2,
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "100vw",
            padding: "2vw",
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: 480,
              background: "rgba(255,255,255,0.96)",
              borderRadius: 20,
              boxShadow: "0 8px 32px rgba(80,0,120,0.10)",
              padding: "2.5rem 2rem",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <h2
              className="text-center mb-4"
              style={{ fontWeight: 700, color: "#4B267D" }}
            >
              Acessos ao Ginásio
            </h2>
            <Button
              variant="primary"
              style={{
                background: "#a084e8",
                border: "none",
                borderRadius: 8,
                height: 44,
                fontWeight: 700,
                fontSize: 16,
                boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                transition: "box-shadow 0.2s, background 0.2s",
                marginBottom: 24,
                width: "100%",
                maxWidth: 220,
              }}
              onClick={() => setShowQr((v) => !v)}
              onMouseOver={e => {
                e.currentTarget.style.boxShadow = "0 4px 16px rgba(160,132,232,0.25)";
                e.currentTarget.style.background = "#8f6be8";
              }}
              onMouseOut={e => {
                e.currentTarget.style.boxShadow = "0 2px 8px rgba(160,132,232,0.10)";
                e.currentTarget.style.background = "#a084e8";
              }}
            >
              Novo Acesso
            </Button>
            <Collapse in={showQr}>
              <div style={{ margin: "18px 0 30px 0", textAlign: "center" }}>
                <img
                  src={exampleQr}
                  alt="QR Code Exemplo"
                  style={{
                    width: 180,
                    height: 180,
                    borderRadius: 12,
                    border: "2px solid #a084e8",
                    background: "#fff",
                    boxShadow: "0 2px 12px rgba(160,132,232,0.10)",
                  }}
                />
                <div style={{ fontSize: 13, color: "#4B267D", marginTop: 8 }}>
                  Mostre este QR Code na entrada do ginásio
                </div>
              </div>
            </Collapse>
            <div style={{ width: "100%" }}>
              {monthsData.map((month, idx) => (
                <Card
                  key={month.value}
                  style={{
                    marginBottom: 10,
                    border: "none",
                    background: "transparent",
                  }}
                >
                  <Card.Header
                    onClick={() =>
                      setOpenMonth(openMonth === idx ? null : idx)
                    }
                    style={{
                      background: "#f5f0ff",
                      borderRadius: 8,
                      cursor: "pointer",
                      fontWeight: 600,
                      color: "#7a5be7",
                      fontSize: 15,
                      border: "1px solid #e0e0e0",
                      marginBottom: 0,
                      padding: "12px 18px",
                      userSelect: "none",
                    }}
                  >
                    {month.label}
                  </Card.Header>
                  <Collapse in={openMonth === idx}>
                    <div>
                      <Card.Body style={{ background: "#faf7ff", borderRadius: 8 }}>
                        {month.days.map((day, i) => (
                          <div
                            key={i}
                            style={{
                              marginBottom: 14,
                              paddingBottom: 10,
                              borderBottom:
                                i !== month.days.length - 1
                                  ? "1px solid #e0e0e0"
                                  : "none",
                            }}
                          >
                            <div style={{ fontWeight: 600, color: "#4B267D" }}>
                              {day.weekday}, {day.date} - ({day.tipo})
                            </div>
                            <div style={{ fontSize: 14, color: "#333", marginTop: 2 }}>
                              entrada <b>{day.entrada}</b>, saída <b>{day.saida}</b> &nbsp;|&nbsp;
                              tempo no espaço <b>{day.tempo}</b>
                            </div>
                          </div>
                        ))}
                      </Card.Body>
                    </div>
                  </Collapse>
                </Card>
              ))}
            </div>
            <Button
              variant="outline-secondary"
              style={{
                marginTop: 28,
                borderRadius: 8,
                fontWeight: 600,
                fontSize: 15,
                width: "100%",
                maxWidth: 220,
                border: "1.5px solid #a084e8",
                color: "#a084e8",
                background: "#fff",
                transition: "background 0.2s, color 0.2s, border 0.2s"
              }}
              onClick={() => navigate("/homepage")}
              onMouseOver={e => {
                e.currentTarget.style.background = "#f5f0ff";
                e.currentTarget.style.color = "#7a5be7";
                e.currentTarget.style.border = "1.5px solid #7a5be7";
              }}
              onMouseOut={e => {
                e.currentTarget.style.background = "#fff";
                e.currentTarget.style.color = "#a084e8";
                e.currentTarget.style.border = "1.5px solid #a084e8";
              }}
            >
              Voltar para Home
            </Button>
          </div>
        </div>
      </div>
      <style>
        {`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        @media (max-width: 600px) {
          .card-header { font-size: 14px !important; }
        }
        `}
      </style>
    </>
  );
};

export default QrCodePage;