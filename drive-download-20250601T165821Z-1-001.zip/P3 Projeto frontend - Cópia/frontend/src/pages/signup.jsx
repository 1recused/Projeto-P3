import React, { useState } from "react";
import { Form, Button, Container, Row, Col, Alert } from "react-bootstrap";

const bgUrl = "https://images.unsplash.com/photo-1595078475328-1ab05d0a6a0e?q=80&w=2000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";
const PRIMARY = "#a084e8";
const PRIMARY_DARK = "#7C4585";

const Signup = () => {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [navigate, setNavigate] = useState();

  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    if (password !== confirmPassword) {
      setError("As senhas não coincidem");
      return;
    }
    try {
      const response = await fetch("http://localhost:5000/utilizador/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ nome, email, password }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erro ao criar conta");
      }
      navigate("/login",{state: { message: "Conta criada com sucesso! Faça login." }});

    } catch (err) {
      setError("Erro ao criar conta. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div
        style={{
          minHeight: "100vh",
          width: "100vw",
          overflow: "hidden",
          fontFamily: "'Inter', 'Roboto', Arial, sans-serif",
          position: "relative",
        }}
      >
        {/* Blurred Background */}
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 0,
            background: `url('${bgUrl}') center/cover no-repeat`,
            filter: "blur(8px)",
            transform: "scale(1.05)",
          }}
        />
        {/* Overlay for slight darkening */}
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1,
            background: "rgba(40,30,60,0.18)",
          }}
        />
        {/* Main Content */}
        <div
          style={{
            position: "relative",
            zIndex: 2,
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "100vw",
            padding: "2vw",
          }}
        >
          <div
            style={{
              display: "flex",
              width: "100%",
              maxWidth: 950,
              minHeight: 480,
              background: "rgba(255,255,255,0.95)",
              borderRadius: 20,
              boxShadow: "0 8px 32px rgba(80,0,120,0.10)",
              overflow: "hidden",
            }}
          >
            {/* Side Image (left, unified with login, sem gradiente) */}
            <div
              style={{
                flex: 1,
                minWidth: 0,
                display: "none",
                position: "relative",
                background: `url('${bgUrl}') center/cover no-repeat`,
                borderTopLeftRadius: 20,
                borderBottomLeftRadius: 20,
                boxShadow: "8px 0 24px -8px rgba(80,0,120,0.08)",
                borderRight: "1px solid #f0eafd",
              }}
              className="d-none d-md-flex"
            />
            {/* Signup Form */}
            <div style={{
              flex: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "2.5rem 2rem",
              position: "relative",
              zIndex: 3,
            }}>
              <Container style={{ maxWidth: 380, padding: 0 }}>
                <Row className="justify-content-md-center">
                  <Col>
                    <h2 className="text-center mb-4" style={{ fontWeight: 700, color: "#4B267D" }}>Criar Conta</h2>
                    {error && <Alert variant="danger">{error}</Alert>}
                    <Form onSubmit={handleSubmit}>
                      <Form.Group className="mb-3">
                        <Form.Label style={{ fontWeight: 600, fontSize: 14 }}>Nome</Form.Label>
                        <Form.Control
                          type="text"
                          placeholder="Digite seu nome"
                          name="nome"
                          value={nome}
                          onChange={(e) => setNome(e.target.value)}
                          style={{
                            borderRadius: 8,
                            border: "1px solid #e0e0e0",
                            height: 44,
                            fontSize: 15,
                            background: "#faf7ff"
                          }}
                        />
                      </Form.Group>
                      <Form.Group  className="mb-3">
                        <Form.Label style={{ fontWeight: 600, fontSize: 14 }}>Email</Form.Label>
                        <Form.Control
                          type="email"
                          placeholder="Digite seu email"
                          name="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          style={{
                            borderRadius: 8,
                            border: "1px solid #e0e0e0",
                            height: 44,
                            fontSize: 15,
                            background: "#faf7ff"
                          }}
                        />
                      </Form.Group>
                      <Form.Group className="mb-3">
                        <Form.Label style={{ fontWeight: 600, fontSize: 14 }}>Senha</Form.Label>
                        <Form.Control
                          type="password"
                          placeholder="Digite sua senha"
                          name="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          style={{
                            borderRadius: 8,
                            border: "1px solid #e0e0e0",
                            height: 44,
                            fontSize: 15,
                            background: "#faf7ff"
                          }}
                        />
                      </Form.Group>
                      <Form.Group className="mb-4">
                        <Form.Label style={{ fontWeight: 600, fontSize: 14 }}>Confirmar Senha</Form.Label>
                        <Form.Control
                          type="password"
                          placeholder="Confirme sua senha"
                          name="confirmPassword"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          style={{
                            borderRadius: 8,
                            border: "1px solid #e0e0e0",
                            height: 44,
                            fontSize: 15,
                            background: "#faf7ff"
                          }}
                        />
                      </Form.Group>
                      <Button
                        variant="primary"
                        type="submit"
                        className="w-100"
                        style={{
                          background: PRIMARY,
                          border: "none",
                          borderRadius: 8,
                          height: 44,
                          fontWeight: 700,
                          fontSize: 16,
                          boxShadow: "0 2px 8px rgba(160,132,232,0.10)",
                          transition: "box-shadow 0.2s, background 0.2s"
                        }}
                        onMouseOver={e => {
                          e.currentTarget.style.boxShadow = "0 4px 16px rgba(160,132,232,0.25)";
                          e.currentTarget.style.background = PRIMARY_DARK;
                        }}
                        onMouseOut={e => {
                          e.currentTarget.style.boxShadow = "0 2px 8px rgba(160,132,232,0.10)";
                          e.currentTarget.style.background = PRIMARY;
                        }}
                      >
                        Criar Conta
                      </Button>
                    </Form>
                  </Col>
                </Row>
                <Row className="justify-content-md-center mt-3">
                  <Col className="text-center">
                    <p style={{ fontSize: 14 }}>
                      Já tem conta? <a href="/login" style={{ color: "#a084e8", fontWeight: 600 }}>Entre agora</a>
                    </p>
                  </Col>
                </Row>
              </Container>
            </div>
          </div>
        </div>
      </div>
      <style>
        {`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        @media (max-width: 900px) {
            .d-md-flex { display: none !important; }
        }
        `}
      </style>
    </>
  );
};

export default Signup;