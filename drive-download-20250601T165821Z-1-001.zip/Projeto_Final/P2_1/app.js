const express = require('express');
const session = require('express-session');
const app = express();
const cors = require('cors');

app.use(cors({
    origin: '*' // Permite todas as origens
}));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));

// View engine
app.set('view engine', 'ejs');
app.set('views', './views');

// Static files
app.use(express.static('public'));
app.use("/assets", express.static("./assets"));

// Routes
app.use('/', require('./routes/main.route')); // a seguir a barra main
app.use('/', require('./routes/utilizador.route')); //utilizador a seguir a barra
app.use('/', require('./routes/planos.route')); // planos a seguir a barra

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
}); 
