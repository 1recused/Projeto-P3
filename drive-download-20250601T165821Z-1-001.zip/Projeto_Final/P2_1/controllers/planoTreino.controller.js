const PlanoTreino = require('../models/planoTreino.model');

exports.create = async (req, res) => {
    try {
        const planoTreino = new PlanoTreino({
            utilizadorId: req.session.userId,
            nome: req.body.nome,
            descricao: req.body.descricao,
            exercicios: req.body.exercicios
        });

        await planoTreino.save();
        res.redirect('/planosdetreino');
    } catch (error) {
        console.error('Error:', error);
        res.redirect('/planosdetreino');
    }
};

exports.update = async (req, res) => {
    try {
        const planoTreino = await PlanoTreino.findByIdAndUpdate(
            req.params.id,
            {
                nome: req.body.nome,
                descricao: req.body.descricao,
                exercicios: req.body.exercicios
            },
            { new: true }
        );

        if (!planoTreino) {
            return res.status(404).send('Plano de treino não encontrado');
        }

        res.redirect('/planosdetreino');
    } catch (error) {
        console.error('Error:', error);
        res.redirect('/planosdetreino');
    }
};

exports.delete = async (req, res) => {
    try {
        await PlanoTreino.findByIdAndDelete(req.params.id);
        res.redirect('/planosdetreino');
    } catch (error) {
        console.error('Error:', error);
        res.redirect('/planosdetreino');
    }
}; 