const PlanoTreino = require('../models/planoTreino.model');

exports.create = async (req, res) => {
    try {
        const planoData = {
            nome: req.body.nome,
            descricao: req.body.descricao,
            utilizador_id: req.session.userId,
            exercicios: req.body.exercises
        };

        await PlanoTreino.create(planoData);
        res.redirect('/planosdetreino');
    } catch (error) {
        console.error('Create plan error:', error);
        res.redirect('/planos/novo');
    }
};

exports.edit = async (req, res) => {
    try {
        const plano = await PlanoTreino.findById(req.params.id);
        if (!plano) {
            return res.redirect('/planosdetreino');
        }
        res.render('pages/editar-plano', { plano, utilizador: req.session.user });
    } catch (error) {
        console.error('Edit plan error:', error);
        res.redirect('/planosdetreino');
    }
};

exports.update = async (req, res) => {
    try {
        const planoData = {
            nome: req.body.nome,
            descricao: req.body.descricao,
            exercicios: req.body.exercises
        };

        await PlanoTreino.update(req.params.id, planoData);
        res.redirect('/planosdetreino');
    } catch (error) {
        console.error('Update plan error:', error);
        res.redirect('/planosdetreino');
    }
};

exports.delete = async (req, res) => {
    try {
        await PlanoTreino.delete(req.params.id);
        res.redirect('/planosdetreino');
    } catch (error) {
        console.error('Delete plan error:', error);
        res.redirect('/planosdetreino');
    }
}; 