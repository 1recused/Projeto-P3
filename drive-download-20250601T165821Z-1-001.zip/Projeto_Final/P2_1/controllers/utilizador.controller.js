const Utilizador = require('../models/utilizador.model');
const bcrypt = require('bcrypt');

exports.create = async (req, res) => {
    try {
       
        if (!req.body.nome || !req.body.email || !req.body.password) {
            console.log("erro 1");
            return res.status(400).json({ 
                success: false, 
                message: "Todos os campos são obrigatórios." 
            });
        }
        const existingUser = await Utilizador.findByEmail(req.body.email);
        if (existingUser) {
            console.log("erro 2");
            return res.status(400).json({ 
                success: false, 
                message: "Email já está em uso." 
            });
        }

        await Utilizador.create(req.body);
        
        return res.status(201).json({
            success: true,
            message: "Utilizador criado com sucesso."
        });
    } catch (error) {
        console.error('Create error:', error);
        res.status(500).json({
            success: false,
            message: "Erro ao criar utilizador."
        });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await Utilizador.findByEmail(email);

        if (!user) {
          //  return res.redirect('/login');
          return res.status(401).json({message: "Utilizador não encontrado."});
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            //return res.redirect('/login');
            return res.status(401).json({message: "Senha incorreta."});
        }

        req.session.userId = user.id;
        res.redirect('/homepage');
    } catch (error) {
        console.error('Login error:', error);
        return res.status(500).json({message: "Erro no servidor."});
       
    }
};

exports.findOne = async (req, res) => {
    try {
        const user = await Utilizador.findById(req.params.id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "Usuário não encontrado."
            });
        }
        res.render('pages/perfil', { utilizador: user });
    } catch (error) {
        console.error('FindOne error:', error);
        res.status(500).json({
            success: false,
            message: "Erro ao buscar usuário."
        });
    }
};

exports.findOneJson = async (req, res) => {
    try {
        const user = await Utilizador.findById(req.params.id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "Usuário não encontrado."
            });
        }
        res.json(user);
    } catch (error) {
        console.error('FindOne error:', error);
        res.status(500).json({
            success: false,
            message: "Erro ao buscar usuário."
        });
    }
};

exports.update = async (req, res) => {
    try {
        if (!req.body.id) {
            return res.status(400).json({
                success: false,
                message: "ID não fornecido."
            });
        }

        await Utilizador.update(req.body.id, req.body);
        res.redirect('/perfil');
    } catch (error) {
        console.error('Update error:', error);
        res.status(500).json({
            success: false,
            message: "Erro ao atualizar usuário."
        });
    }
};

exports.delete = async (req, res) => {
    try {
        await Utilizador.delete(req.params.id);
        req.session.destroy();
        res.redirect('/');
    } catch (error) {
        console.error('Delete error:', error);
        res.status(500).json({
            success: false,
            message: "Erro ao deletar usuário."
        });
    }
};

exports.deleteJson = async (req, res) => {
    try {
        await Utilizador.delete(req.params.id);
    } catch (error) {
        console.error('Delete error:', error);
        res.status(500).json({
            success: false,
            message: "Erro ao deletar usuário."
        });
    }
};
exports.loginJson = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await Utilizador.findByEmail(email);

        const validPassword = await bcrypt.compare(password, user.password);
        req.session.userId = user.id;
        
    } catch (error) {
        console.error('Login error:', error);
    }
};
