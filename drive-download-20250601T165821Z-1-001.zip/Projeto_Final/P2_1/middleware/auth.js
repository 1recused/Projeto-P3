const auth = (req, res, next) => {
    // Check if user is logged in via session
    if (req.session && req.session.userId) {
        return next();
    }
    
    // If not authenticated, redirect to login page
    res.redirect('/login');
};

module.exports = auth;