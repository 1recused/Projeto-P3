const db = require('../config/db.config');

class PlanoTreino {
    static async create(planoData) {
        const conn = await db.getConnection();
        try {
            await conn.beginTransaction();

            // Insert plan
            const [planResult] = await conn.query(
                'INSERT INTO planos_treino (nome, descricao, utilizador_id) VALUES (?, ?, ?)',
                [planoData.nome, planoData.descricao, planoData.utilizador_id]
            );

            // Insert exercises if they exist
            if (planoData.exercicios && planoData.exercicios.length > 0) {
                for (const exercicio of Object.values(planoData.exercicios)) {
                    await conn.query(
                        'INSERT INTO exercicios (plano_id, nome, series, repeticoes) VALUES (?, ?, ?, ?)',
                        [planResult.insertId, exercicio.nome, exercicio.series, exercicio.repeticoes]
                    );
                }
            }

            await conn.commit();
            return planResult.insertId;
        } catch (error) {
            await conn.rollback();
            throw error;
        } finally {
            conn.release();
        }
    }

    static async findByUserId(userId) {
        try {
            const [plans] = await db.query(
                `SELECT p.*, 
                    GROUP_CONCAT(e.id) as exercise_ids,
                    GROUP_CONCAT(e.nome) as exercise_names,
                    GROUP_CONCAT(e.series) as exercise_series,
                    GROUP_CONCAT(e.repeticoes) as exercise_reps
                FROM planos_treino p
                LEFT JOIN exercicios e ON p.id = e.plano_id
                WHERE p.utilizador_id = ?
                GROUP BY p.id`,
                [userId]
            );

            return plans.map(plan => {
                const exercises = [];
                if (plan.exercise_ids) {
                    const ids = plan.exercise_ids.split(',');
                    const names = plan.exercise_names.split(',');
                    const series = plan.exercise_series.split(',');
                    const reps = plan.exercise_reps.split(',');

                    for (let i = 0; i < ids.length; i++) {
                        exercises.push({
                            id: ids[i],
                            nome: names[i],
                            series: series[i],
                            repeticoes: reps[i]
                        });
                    }
                }

                return {
                    id: plan.id,
                    nome: plan.nome,
                    descricao: plan.descricao,
                    created_at: plan.created_at,
                    exercicios: exercises
                };
            });
        } catch (error) {
            throw error;
        }
    }

    static async delete(id) {
        try {
            await db.query('DELETE FROM planos_treino WHERE id = ?', [id]);
        } catch (error) {
            throw error;
        }
    }

    static async update(id, planoData) {
        const conn = await db.getConnection();
        try {
            await conn.beginTransaction();

            // Update plan
            await conn.query(
                'UPDATE planos_treino SET nome = ?, descricao = ? WHERE id = ?',
                [planoData.nome, planoData.descricao, id]
            );

            // Delete existing exercises
            await conn.query('DELETE FROM exercicios WHERE plano_id = ?', [id]);

            // Insert new exercises
            if (planoData.exercicios && planoData.exercicios.length > 0) {
                for (const exercicio of Object.values(planoData.exercicios)) {
                    await conn.query(
                        'INSERT INTO exercicios (plano_id, nome, series, repeticoes) VALUES (?, ?, ?, ?)',
                        [id, exercicio.nome, exercicio.series, exercicio.repeticoes]
                    );
                }
            }

            await conn.commit();
        } catch (error) {
            await conn.rollback();
            throw error;
        } finally {
            conn.release();
        }
    }

    static async findById(id) {
        try {
            const [plans] = await db.query(
                `SELECT p.*, 
                    GROUP_CONCAT(e.id) as exercise_ids,
                    GROUP_CONCAT(e.nome) as exercise_names,
                    GROUP_CONCAT(e.series) as exercise_series,
                    GROUP_CONCAT(e.repeticoes) as exercise_reps
                FROM planos_treino p
                LEFT JOIN exercicios e ON p.id = e.plano_id
                WHERE p.id = ?
                GROUP BY p.id`,
                [id]
            );

            if (!plans || plans.length === 0) {
                return null;
            }

            const plan = plans[0];
            const exercises = [];

            if (plan.exercise_ids) {
                const ids = plan.exercise_ids.split(',');
                const names = plan.exercise_names.split(',');
                const series = plan.exercise_series.split(',');
                const reps = plan.exercise_reps.split(',');

                for (let i = 0; i < ids.length; i++) {
                    exercises.push({
                        id: ids[i],
                        nome: names[i],
                        series: series[i],
                        repeticoes: reps[i]
                    });
                }
            }

            return {
                id: plan.id,
                nome: plan.nome,
                descricao: plan.descricao,
                created_at: plan.created_at,
                exercicios: exercises
            };
        } catch (error) {
            throw error;
        }
    }
}

module.exports = PlanoTreino; 