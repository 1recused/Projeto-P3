const db = require('../config/db.config');
const bcrypt = require('bcrypt');

class Utilizador {
    constructor(utilizador) {
        this.id = utilizador.id;
        this.nome = utilizador.nome;
        this.email = utilizador.email;
        this.password = utilizador.password;
    }

    static async create(newUtilizador) {
        try {
            const hashedPassword = await bcrypt.hash(newUtilizador.password, 10);
            const [result] = await db.query(
                'INSERT INTO utilizadores (nome, email, password) VALUES (?, ?, ?)',
                [newUtilizador.nome, newUtilizador.email, hashedPassword]
            );
            return result;
        } catch (error) {
            throw error;
        }
    }

    static async findById(id) {
        try {
            const [rows] = await db.query('SELECT * FROM utilizadores WHERE id = ?', [id]);
            return rows[0];
        } catch (error) {
            throw error;
        }
    }

    static async findByEmail(email) {
        try {
            const [rows] = await db.query('SELECT * FROM utilizadores WHERE email = ?', [email]);
            return rows[0];
        } catch (error) {
            throw error;
        }
    }

    static async update(id, utilizador) {
        try {
            let query = 'UPDATE utilizadores SET nome = ?, email = ?';
            let params = [utilizador.nome, utilizador.email];

            if (utilizador.password) {
                const hashedPassword = await bcrypt.hash(utilizador.password, 10);
                query += ', password = ?';
                params.push(hashedPassword);
            }

            query += ' WHERE id = ?';
            params.push(id);

            const [result] = await db.query(query, params);
            return result;
        } catch (error) {
            throw error;
        }
    }

    static async delete(id) {
        try {
            const [result] = await db.query('DELETE FROM utilizadores WHERE id = ?', [id]);
            return result;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Utilizador;