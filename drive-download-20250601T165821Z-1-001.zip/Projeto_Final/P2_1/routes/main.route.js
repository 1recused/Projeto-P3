const express = require('express');
const router = express.Router();
const Utilizador = require('../models/utilizador.model'); // Updated path
const auth = require('../middleware/auth');
const PlanoTreino = require('../models/planoTreino.model'); // Updated path

router.get("/", (req, res) => {
    res.render("pages/index");
});

router.get("/login", (req, res) => {
    res.render("pages/login");
});

router.get("/register", (req, res) => {
    res.render("pages/register");
});

router.get("/homepage", async (req, res) => {
    try {
        const userId = req.session.userId;
        if (!userId) {
            return res.redirect('/login');
        }

        const utilizador = await Utilizador.findById(userId);
        if (!utilizador) {
            return res.redirect('/login');
        }

        res.render("pages/homepage", { utilizador });
    } catch (error) {
        console.error('Error:', error);
        res.redirect('/login');
    }
});

router.get("/planosdetreino", async (req, res) => {
    try {
        const userId = req.session.userId;
        if (!userId) {
            return res.redirect('/login');
        }

        const utilizador = await Utilizador.findById(userId);
        if (!utilizador) {
            return res.redirect('/login');
        }

        let planosTreino = [];
        try {
            planosTreino = await PlanoTreino.findByUserId(userId);
        } catch (error) {
            console.error('Error fetching planos:', error);
            // If there's an error, we'll just use empty array
        }
        
        res.render("pages/planosdetreino", { 
            utilizador,
            planosTreino 
        });
    } catch (error) {
        console.error('Error:', error);
        res.redirect('/login');
    }
});

router.get("/perfil", auth, async (req, res) => {
    try {
        const userId = req.session.userId;
        
        if (!userId) {
            return res.redirect('/login');
        }

        const utilizador = await Utilizador.findById(userId);
        
        if (!utilizador) {
            return res.redirect('/login');
        }

        res.render('pages/perfil', { utilizador });
    } catch (error) {
        console.error('Error:', error);
        res.redirect('/login');
    }
});

router.post("/utilizador/update/:id", auth, async (req, res) => {
    try {
        const userId = req.params.id;
        const updates = {
            nome: req.body.nome,
            email: req.body.email
        };
        
        // Only add password to updates if it was provided
        if (req.body.password) {
            updates.password = req.body.password;
        }

        const utilizador = await Utilizador.findByIdAndUpdate(userId, updates, { new: true });
        
        if (!utilizador) {
            return res.redirect('/login');
        }

        res.redirect('/perfil');
    } catch (error) {
        console.error('Error:', error);
        res.redirect('/perfil');
    }
});

module.exports = router;