const express = require('express');
const router = express.Router();
const planosController = require('../controllers/planos.controller');
const auth = require('../middleware/auth');

router.get('/planos/novo', auth, (req, res) => {
    res.render('pages/novo-plano', { utilizador: req.session.user });
});

router.post('/planos/create', auth, planosController.create);
router.get('/planos/edit/:id', auth, planosController.edit);
router.post('/planos/update/:id', auth, planosController.update);
router.get('/planos/delete/:id', auth, planosController.delete);

module.exports = router; 