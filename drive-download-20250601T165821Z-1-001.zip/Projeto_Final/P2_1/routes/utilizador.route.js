const express = require("express");
const router = express.Router();
const utilizador = require("../controllers/utilizador.controller");
const auth = require("../middleware/auth");

// Public routes
router.post("/utilizador/login", utilizador.login);
router.post("/utilizador/create", utilizador.create);

// Protected routes
router.get("/utilizador/:id", utilizador.findOne);
router.post("/utilizador/update", auth, utilizador.update);
router.get("/utilizador/delete/:id", auth, utilizador.delete);

router.get("/utilizador/json/:id", utilizador.findOneJson);
router.get("/utilizador/delete/json/:id", utilizador.deleteJson);
router.get("/utilizador/login/json", utilizador.loginJson);
module.exports = router;