import React, {useEffect,useState} from "react";
import { View,Text,FlatList,StyleSheet } from "react-native";
import axios from "axios";
import { use } from "react";
export default function HomeScreen() {
    const [dados,setDados]=useState([]);
    useEffect(()=>{
        axios.get('http://192.168.1.140:5000/utilizador/json/3')
        .then(response=>{
            console.log(response.data);
            setDados([response.data]);
        
        })
        .catch(error=>console.error('erro: ',error));
    },[]);
    return (
        <View style={styles.container}>
        <Text style={styles.title}>lista1234566</Text>
        <FlatList
        data={dados}
        keyExtractor={(item,index)=>item.id? item.id.toString():index.toString()}
        renderItem={({item})=>(
            <Text style={styles.item}>{item.nome} ({item.email})</Text>
        )}
        />
        </View>
    );
}
const styles=StyleSheet.create({
    container:{flex:1,padding:20,backgroundColor:'fff'},
    title:{fontSize:24,fontWeight:'bold',marginBottom:10},
    item: {fontSize:18,paddingVertical:5},
})