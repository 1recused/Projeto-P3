import React, {useState} from 'react';
import {View,Text,TextInput,Button,StyleSheet,Alert} from 'react-native';
import axios from 'axios';
export default function LoginScreen({navigation}){
    const [email,setEmail]= useState('');
    const [password,setPassword]= useState('');
    const fazerLogin = async ()=>{
        try {
            const response = await axios.post('http://192.168.1.140:5000/utilizador/login/json',{
                email,
                password
            });
            Alert.alert('sucesso', 'login com sucesso');
            //navigation.navigate('home');
        } catch (error) {
            console.error('erro no login', error.response?.data || error.message);
            Alert.alert('erro', 'dados errados');
        }
    };
return (
    <View style ={styles.container}>
        <Text style ={styles.title}>login</Text>
        <TextInput
        placeholder="email"
        value={email}
        onChangeText={setEmail}
        style={styles.input}
        keyboardType="email-address"
        />
   

<TextInput
placeholder="password"
value={password}
onChangeText={setPassword}
style={styles.input}
secureTextEntry
/>
<Button title='Entrar'onPress={fazerLogin}/>
</View>
);
}
const styles = StyleSheet.create({
    container: { flex: 1, padding: 20, justifyContent: 'center' },
    title: { fontSize: 26, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
    input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 15, borderRadius: 8 },
  });